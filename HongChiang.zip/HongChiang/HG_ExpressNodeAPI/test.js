var ffi = require("ffi");
 
var libm = new ffi.Library("/home/vcpi/nodeAPI_lib", { "func_read": [ "int", [ "int" ] ] });

console.log( libm.func_read(2));

// You can also access just functions in the current process by passing a null 
var current = new ffi.Library(null, { "atoi": [ "int32", [ "string" ] ] });
current.atoi("1234"); // 1234 
